<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="fi_FI">
<context>
    <name>QObject</name>
    <message>
        <location filename="main.cpp" line="266"/>
        <source>LeftToRight</source>
        <translation>VasemmaltaOikealle</translation>
    </message>
</context>
<context>
    <name>unetbootin</name>
    <message>
        <location filename="unetbootin.cpp" line="4323"/>
        <source>Hard Disk</source>
        <translation>Kiintolevy</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="4327"/>
        <source>USB Drive</source>
        <translation>USB-asema</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3549"/>
        <source>ISO</source>
        <translation>ISO</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3541"/>
        <source>Floppy</source>
        <translation>Levyke</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="302"/>
        <source>either</source>
        <translation>Ei kumpikaan</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="281"/>
        <source>LiveUSB persistence</source>
        <translation>LiveUSB:n pysyvyys</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="296"/>
        <source>FAT32-formatted USB drive</source>
        <translation>FAT32-alustettu USB-asema</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="300"/>
        <source>EXT2-formatted USB drive</source>
        <translation>EXT2-alustettu USB-asema</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="676"/>
        <source>Open Disk Image File</source>
        <translation>Avaa levykuvatiedosto</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="676"/>
        <source>All Files</source>
        <translation>Kaikki tiedostot</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="710"/>
        <source>All Files (*)</source>
        <translation>Kaikki tiedostot (*)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="694"/>
        <source>Open Kernel File</source>
        <translation>Avaa kernel-tiedosto</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="702"/>
        <source>Open Initrd File</source>
        <translation>Avaa initrd-tiedosto</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="710"/>
        <source>Open Bootloader Config File</source>
        <translation>Avaa käynnistyslataajan asetustiedosto</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="732"/>
        <source>Insert a USB flash drive</source>
        <translation>Kiinnitä USB-asema</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="733"/>
        <source>No USB flash drives were found. If you have already inserted a USB drive, try reformatting it as FAT32.</source>
        <translation>USB-asemia ei löytynyt. Jos olet jo kiinnittänyt USB-aseman, yritä alustaa se käyttäen FAT32-tiedostojärjestelmää.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="752"/>
        <source>%1 not mounted</source>
        <translation>%1 ei ole liitetty</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="753"/>
        <source>You must first mount the USB drive %1 to a mountpoint. Most distributions will do this automatically after you remove and reinsert the USB drive.</source>
        <translation>Sinun täytyy ensin liittää USB-asema %1 liitospisteeseen. Useimmat jakeluversiot tekevät tämän automaattisesti kun poistat ja laitat USB-aseman takaisin paikoilleen.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="768"/>
        <source>Select a distro</source>
        <translation>Valitse jakelu</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="769"/>
        <source>You must select a distribution to load.</source>
        <translation>Sinun täytyy valita ladattava jakelu.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="783"/>
        <source>Select a disk image file</source>
        <translation>Valitse levykuva.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="784"/>
        <source>You must select a disk image file to load.</source>
        <translation>Sinun täytyy valita ladattava levykuva.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="798"/>
        <source>Select a kernel and/or initrd file</source>
        <translation>Valitse kernel- ja/tai initrd-tiedosto</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="799"/>
        <source>You must select a kernel and/or initrd file to load.</source>
        <translation>Sinun täytyy valita ladattava kernel ja/tai initrd-tiedosto.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="813"/>
        <source>Diskimage file not found</source>
        <translation>Levykuvaa ei löytynyt.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="814"/>
        <source>The specified diskimage file %1 does not exist.</source>
        <translation>Levykuvatiedostoa %1 ei ole olemassa.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="828"/>
        <source>Kernel file not found</source>
        <translation>Kernel-tiedostoa ei löytynyt</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="829"/>
        <source>The specified kernel file %1 does not exist.</source>
        <translation>Kernel-tiedostoa %1 ei ole olemassa.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="843"/>
        <source>Initrd file not found</source>
        <translation>Initrd-tiedostoa ei löytynyt</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="844"/>
        <source>The specified initrd file %1 does not exist.</source>
        <translation>Initrd-tiedostoa %1 ei ole olemassa.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="948"/>
        <source>%1 exists, overwrite?</source>
        <translation>%1 on jo olemassa, korvataanko se?</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="949"/>
        <source>The file %1 already exists. Press &apos;Yes to All&apos; to overwrite it and not be prompted again, &apos;Yes&apos; to overwrite files on an individual basis, and &apos;No&apos; to retain your existing version. If in doubt, press &apos;Yes to All&apos;.</source>
        <translation>Tiedosto &apos;%1&apos; on jo olemassa. Valitse jokin seuraavista toiminnoista: Kyllä kaikkiin - korvaa kaikki aikaisemmat tiedostot; Kyllä - korvaa tiedostot yksi kerrallaan; Ei - säästä nykyinen versio.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="975"/>
        <source>%1 is out of space, abort installation?</source>
        <translation>%1 - levytila lopussa, perutaanko asennus?</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="976"/>
        <source>The directory %1 is out of space. Press &apos;Yes&apos; to abort installation, &apos;No&apos; to ignore this error and attempt to continue installation, and &apos;No to All&apos; to ignore all out-of-space errors.</source>
        <translation>Hakemistosta %1 on loppunut tila. Valitse jokin seuraavista toiminnoista: Kyllä - keskeytä asennus; Ei - hylkää tämä virheilmoitus ja yritä jatkaa asennusta; Ei kaikkiin - hylkää kaikki mahdolliset levytilaan liittyvät ilmoitukset jatkossa.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1070"/>
        <source>Locating kernel file in %1</source>
        <translation>Paikallistetaan kerneltiedostoa kohteessa %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1121"/>
        <source>Copying kernel file from %1</source>
        <translation>Kopioidaan kerneltiedostoa kohteesta %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1127"/>
        <source>Locating initrd file in %1</source>
        <translation>Paikallistetaan initrd-tiedostoa kohteessa %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1168"/>
        <source>Copying initrd file from %1</source>
        <translation>Kopioidaan initrd-tiedostoa kohteesta %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1263"/>
        <source>Extracting bootloader configuration</source>
        <translation>Puretaan käynnistyslataajan asetuksia</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1521"/>
        <source>&lt;b&gt;Extracting compressed iso:&lt;/b&gt; %1</source>
        <translation>&lt;/a&gt;Puretaan tiivistettyä iso-tiedostoa:&lt;/a&gt; %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1785"/>
        <source>Copying file, please wait...</source>
        <translation>Kopioidaan tiedostoa, odota...</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2602"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</source>
        <translation>&lt;b&gt;Lähde:&lt;/b&gt; &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2603"/>
        <source>&lt;b&gt;Destination:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Kohde:&lt;/b&gt; %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1788"/>
        <source>&lt;b&gt;Copied:&lt;/b&gt; 0 bytes</source>
        <translation>&lt;b&gt;Kopioitu:&lt;/b&gt; 0 tavua</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1826"/>
        <source>Extracting files, please wait...</source>
        <translation>Puretaan tiedostoja, odota...</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1827"/>
        <source>&lt;b&gt;Archive:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Arkisto:&lt;/b&gt;  %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1828"/>
        <source>&lt;b&gt;Source:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Lähde:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1829"/>
        <source>&lt;b&gt;Destination:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Kohde:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1830"/>
        <source>&lt;b&gt;Extracted:&lt;/b&gt; 0 of %1 files</source>
        <translation>&lt;b&gt;Purettu:&lt;/b&gt;  0 / %1 tiedostoa</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1833"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; %1 (%2)</source>
        <translation>&lt;b&gt;Lähde:&lt;/b&gt; %1 (%2)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1834"/>
        <source>&lt;b&gt;Destination:&lt;/b&gt; %1%2</source>
        <translation>&lt;b&gt;Kohde:&lt;/b&gt; %1%2</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1835"/>
        <source>&lt;b&gt;Extracted:&lt;/b&gt; %1 of %2 files</source>
        <translation>&lt;b&gt;Purettu:&lt;/b&gt; %1 / %2 tiedostoa</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2601"/>
        <source>Downloading files, please wait...</source>
        <translation>Ladataan tiedostoja, odota...</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2604"/>
        <source>&lt;b&gt;Downloaded:&lt;/b&gt; 0 bytes</source>
        <translation>&lt;b&gt;Ladattu:&lt;/b&gt; 0 tavua</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2728"/>
        <source>Download of %1 %2 from %3 failed. Please try downloading the ISO file from the website directly and supply it via the diskimage option.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2766"/>
        <source>&lt;b&gt;Downloaded:&lt;/b&gt; %1 of %2</source>
        <translation>&lt;b&gt;Ladattu:&lt;/b&gt; %1 / %2</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2781"/>
        <source>&lt;b&gt;Copied:&lt;/b&gt; %1 of %2</source>
        <translation>&lt;b&gt;Kopioitu:&lt;/b&gt; %1 / %2</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2872"/>
        <source>Searching in &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</source>
        <translation>Haetaan: &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2876"/>
        <source>%1/%2 matches in &lt;a href=&quot;%3&quot;&gt;%3&lt;/a&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3149"/>
        <source>%1 not found</source>
        <translation>%1 ei löytynyt</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3150"/>
        <source>%1 not found. This is required for %2 install mode.
Install the &quot;%3&quot; package or your distribution&apos;s equivalent.</source>
        <translation>Kohdetta %1 ei löytynyt. Tämä tarvitaan asennustoiminnolle %2.
Asenna ensin paketti &quot;%3&quot;, tai jokin muu linux-jakeluasi vastaava paketti.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3441"/>
        <source>(Current)</source>
        <translation>(Nykyinen)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3442"/>
        <source>(Done)</source>
        <translation>(Valmis)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3734"/>
        <source>Configuring grub2 on %1</source>
        <translation>Määritetään grub2:n asetuksia: %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3746"/>
        <source>Configuring grldr on %1</source>
        <translation>Konfiguroidaan grldr kohteessa %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3774"/>
        <source>Configuring grub on %1</source>
        <translation>Konfiguroidaan grub kohteessa %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="4069"/>
        <source>Installing syslinux to %1</source>
        <translation>Asennetaan syslinuxia: %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="4104"/>
        <source>Installing extlinux to %1</source>
        <translation>Asennetaan extlinuxia: %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="4275"/>
        <source>Syncing filesystems</source>
        <translation>Synkronoidaan tiedostojärjestelmiä</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="4280"/>
        <source>Setting up persistence</source>
        <translation>Asetetaan pysyvyyttä</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="4325"/>
        <source>After rebooting, select the </source>
        <translation>Uudelleenkäynnistyksen jälkeen valitse </translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="4330"/>
        <source>After rebooting, select the USB boot option in the BIOS boot menu.%1
Reboot now?</source>
        <translation>Valitse USB-asema käynnistettäväksi mediaksi BIOS-valikosta uudelleenkäynnistyksen yhteydessä. %1
Käynnistetäänkö kone uudelleen nyt?</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="4333"/>
        <source>The created USB device will not boot off a Mac. Insert it into a PC, and select the USB boot option in the BIOS boot menu.%1</source>
        <translation>Luotua USB-laitetta ei voi käynnistää Mac-tietokoneella. Syötä USB-laite PC-tietokoneeseen ja valitse USB-käynnistys tietokoneen BIOS-asetuksista.%1</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="47"/>
        <source>
*IMPORTANT* Before rebooting, place an Ubuntu alternate (not desktop) install iso file on the root directory of your hard drive or USB drive. These can be obtained from cdimage.ubuntu.com</source>
        <translation>
*TÄRKEÄÄ* Ennen tietokoneen uudelleenkäynnistystä aseta Ubuntun vaihtoehtoisversion (alternate) asennustiedosto kiintolevysi tai USB-laitteesi juurikansioon. Tiedostot voi ladata osoitteesta cdimage.ubuntu.com</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="261"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;mirrors.kernel.org&apos; when prompted for a server, and enter &apos;/centos/%1/os/%2&apos; when asked for the folder.</source>
        <translation>
*TÄRKEÄÄ* Uudelleenkäynnistyksen jälkeen ohita ja jätä huomiotta mahdolliset virheilmoitukset ja valitse &apos;takaisin&apos;, mikäli CD-levyä kysytään. Tämän jälkeen mene päävalikkoon, valitse &apos;Aloita asennus&apos; -toiminto, valitse lähteeksi &apos;Verkko&apos;, valitse protokollaksi &apos;HTTP&apos;, aseta palvelinta kysyessä arvoksi &apos;mirror.kernel.org&apos; ja kansiota kysyttäessä aseta arvoksi &apos;/centos/%1/os/%2&apos;.</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="318"/>
        <source>
*IMPORTANT* Before rebooting, place a Debian install iso file on the root directory of your hard drive or USB drive. These can be obtained from cdimage.debian.org</source>
        <translation>
*TÄRKEÄÄ* Ennen uudelleenkäynnistysta aseta Debian -käyttöjärjestelmän iso-tyypin asennustiedosto kiintolevysi tai USB-asemasi juurikansioon. Tiedostot voi hankkia osoitteesta cdimage.debian.org</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="395"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.fedora.redhat.com&apos; when prompted for a server, and enter &apos;/pub/fedora/linux/development/%1/os&apos; when asked for the folder.</source>
        <translation>
*TÄRKEÄÄ* Uudelleenkäynnistyksen jälkeen ohita ja jätä huomiotta mahdolliset virheilmoitukset ja valitse &apos;takaisin&apos;, mikäli CD-levyä kysytään. Tämän jälkeen mene päävalikkoon, valitse &apos;Aloita asennus&apos; -toiminto, valitse lähteeksi &apos;Verkko&apos;, valitse protokollaksi &apos;HTTP&apos;, aseta palvelinta kysyessä arvoksi &apos;download.fedora.redhat.com&apos; ja kansiota kysyttäessä aseta arvoksi &apos;/pub/fedora/linux/development/%1/os&apos;.</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="401"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.fedora.redhat.com&apos; when prompted for a server, and enter &apos;/pub/fedora/linux/releases/%1/Fedora/%2/os&apos; when asked for the folder.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="756"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.opensuse.org&apos; when prompted for a server, and enter &apos;/factory/repo/oss&apos; when asked for the folder.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="762"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.opensuse.org&apos; when prompted for a server, and enter &apos;/distribution/%1/repo/oss&apos; when asked for the folder.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="764"/>
        <source>== Select Distribution ==</source>
        <translation>== Valitse jakelu ==</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="24"/>
        <source>== Select Version ==</source>
        <translation>== Valitse versio ==</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="23"/>
        <source>Welcome to &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootin&lt;/a&gt;, the Universal Netboot Installer. Usage:&lt;ol&gt;&lt;li&gt;Select a distribution and version to download from the list above, or manually specify files to load below.&lt;/li&gt;&lt;li&gt;Select an installation type, and press OK to begin installing.&lt;/li&gt;&lt;/ol&gt;</source>
        <translation>Tervetuloa käyttämään &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootinia&lt;/a&gt; (lyhenne sanoista Universal Netboot Installer). Käyttöohjeet:&lt;ol&gt;&lt;li&gt;Valitse jakelu ja jakelun versio pudotusvalikoista tai vaihtoehtoisesti määritä levykuva itse.&lt;/li&gt;&lt;li&gt;Valitse asennustapa ja napsauta OK aloittaaksesi asennuksen USB-asemalle.&lt;/li&gt;&lt;/ol&gt;</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="28"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.archlinux.org/&quot;&gt;http://www.archlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Arch Linux is a lightweight distribution optimized for speed and flexibility.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for installation over the internet (FTP).</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.archlinux.org/&quot;&gt;http://www.archlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Arch Linux on nopeuteen ja joustavuuteen keskittyvä kevyt jakelu.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Oletusversio mahdollistaa asennuksen internetiä käyttäen (FTP).</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="33"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.backtrack-linux.org/&quot;&gt;http://www.backtrack-linux.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; BackTrack is a distribution focused on network analysis and penetration testing.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; BackTrack is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.backtrack-linux.org/&quot;&gt;http://www.backtrack-linux.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; BackTrack on verkkoanalysointiin ja tunkeutumistestaukseen tarkoitettu jakelu.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; BackTrack käynnistyy ja toimii live-tilassa; asennusta ei vaadita jakelun käyttämiseksi.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="38"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.centos.org/&quot;&gt;http://www.centos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; CentOS is a free Red Hat Enterprise Linux clone.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.centos.org/&quot;&gt;http://www.centos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; CentOS on ilmainen Red Hat Enterprise Linux -klooni.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Oletusversio mahdollistaa asennuksen niin internetin (FTP) kautta kuin yhteydettömässäkin tilassa käyttäen etukäteen ladattuja ISO-tiedostoja.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="43"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://clonezilla.org/&quot;&gt;http://clonezilla.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; CloneZilla is a distribution used for disk backup and imaging.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; CloneZilla is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://clonezilla.org/&quot;&gt;http://clonezilla.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; CloneZilla on varmuuskopiointiin ja levykuvien hallintaan tarkoitettu jakelu.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; CloneZilla käynnistyy ja toimii live-tilassa; sen käyttö ei vaadi asennusta.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="48"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://damnsmalllinux.org/&quot;&gt;http://damnsmalllinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Damn Small Linux is a minimalist distribution designed for older computers.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://damnsmalllinux.org/&quot;&gt;http://damnsmalllinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Damn Small Linux on vanhoille tietokoneille suunnattu minimalistinen jakelu.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Live-versio lataa järjestelmän kokonaisuudessaan keskusmuistiin, joten asennus kiintolevylle ei ole välttämätöntä.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="53"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.debian.org/&quot;&gt;http://www.debian.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Debian is a community-developed Linux distribution that supports a wide variety of architectures and offers a large repository of packages.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The NetInstall version allows for installation over FTP. If you would like to use a pre-downloaded install iso, use the HdMedia option, and then place the install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.debian.org/&quot;&gt;http://www.debian.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Debian on laajan yhteisön kehittämä Linux-jakelu. Debian tukee lukuisia arkkitehtuureja ja sen ohjelmistolähteet sisältävät paljon paketteja.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; NetInstall-versio mahdollistaa asennuksen verkon (FTP) kautta. Jos haluat käyttää ennalta ladattua install-versiota, käytä HdMedia-valintaa ja aseta install-version ISO-tiedosto USB-levyn/kiintolevyn juureen.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="59"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.dreamlinux.com.br/&quot;&gt;http://www.dreamlinux.com.br&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Dreamlinux is a user-friendly Debian-based distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="64"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.freedrweb.com/livecd&quot;&gt;http://www.freedrweb.com/livecd&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Dr.Web AntiVirus is an anti-virus emergency kit to restore a system that broke due to malware.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which malware scans can be launched.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="69"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Elive is a Debian-based distribution featuring the Enlightenment window manager.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Elive on Debian-pohjainen jakelu, joka tarjoaa Enlightenment-ikkunahallinnan.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Live-versio mahdollistaa käynnistyksen live-tilaan, josta on mahdollista käynnistää asennusohjelma.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="74"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://fedoraproject.org/&quot;&gt;http://fedoraproject.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Fedora is a Red Hat sponsored community distribution which showcases the latest cutting-edge free/open-source software.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://fedoraproject.org/&quot;&gt;http://fedoraproject.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Fedora on Red Hatin sponsoroima yhteisöön perustuva jakelu, jossa on uusimpia avoimen lähdekoodin ohjelmistoja.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Live-versio mahdollistaa käynnistyksen live-tilaan, josta on mahdollista käynnistää asennusohjelma. NetInstall-versio mahdollistaa asennuksen niin internetin (FTP) kautta kuin yhteydettömässäkin tilassa käyttäen etukäteen ladattuja ISO-tiedostoja.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="79"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.freebsd.org/&quot;&gt;http://www.freebsd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; FreeBSD is a general-purpose Unix-like operating system designed for scalability and performance.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.freebsd.org/&quot;&gt;http://www.freebsd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; FreeBSD on Unix-kaltainen käyttöjärjestelmä, joka on nopea ja skaalautuva.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Oletusversio mahdollistaa asennuksen internetin (FTP) kautta tai yhteydettömässä tilassa käyttäen ennalta ladattuja ISO-tiedostoja.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="84"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.freedos.org/&quot;&gt;http://www.freedos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; FreeDOS is a free MS-DOS compatible operating system.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; See the &lt;a href=&quot;http://fd-doc.sourceforge.net/wiki/index.php?n=FdDocEn.FdInstall&quot;&gt;manual&lt;/a&gt; for installation details.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.freedos.org/&quot;&gt;http://www.freedos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; FreeDOS on ilmainen MS-DOS-yhteensopiva käyttöjärjestelmä.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Lue asennustiedot projektin sivustolla olevasta &lt;a href=&quot;http://fd-doc.sourceforge.net/wiki/index.php?n=FdDocEn.FdInstall&quot;&gt;ohjekirjasta&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="89"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://freenas.org/&quot;&gt;http://www.freenas.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; FreeNAS is an embedded open source NAS (Network-Attached Storage) distribution based on FreeBSD.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The LiveCD version creates a RAM drive for FreeNAS, and uses a FAT formatted floppy disk or USB key for saving the configuration file. The embedded version allows installation to hard disk.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="94"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://frugalware.org/&quot;&gt;http://frugalware.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Frugalware is a general-purpose Slackware-based distro for advanced users.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default option allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="103"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.geexbox.org/&quot;&gt;http://www.geexbox.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; GeeXboX is an Embedded Linux Media Center Distribution.&lt;br/&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="117"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.gnewsense.org/&quot;&gt;http://www.gnewsense.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; gNewSense is an FSF-endorsed distribution based on Ubuntu with all non-free components removed.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="122"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://gujin.sourceforge.net/&quot;&gt;http://gujin.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Gujin is a graphical boot manager which can bootstrap various volumes and files.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Gujin simply boots and runs; no installation is required to use it.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="127"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://ftp.kaspersky.com/devbuilds/RescueDisk/&quot;&gt;http://ftp.kaspersky.com/devbuilds/RescueDisk/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Kaspersky Rescue Disk detects and removes malware from your Windows installation.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which malware scans can be launched.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://ftp.kaspersky.com/devbuilds/RescueDisk/&quot;&gt;http://ftp.kaspersky.com/devbuilds/RescueDisk/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Kaspersky Rescue Disk havaitsee ja poistaa haittaohjelmia koneella olevasta Windows-asennuksesta.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Live-versio käynnistyy live-tilaan, josta on mahdollista suorittaa haittaohjelmien etsintä.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="132"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.kubuntu.org/&quot;&gt;http://www.kubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Kubuntu is an official Ubuntu derivative featuring the KDE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.kubuntu.org/&quot;&gt;http://www.kubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Kubuntu on virallinen Ubuntu-johdannainen, jonka työpöytäympäristönä on KDE.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Live-versio on mahdollista käynnistää live-tilaan, josta on mahdollista suorittaa varsinainen asennus. NetInstall-versio mahdollistaa asennuksen verkon (FTP) kautta; sillä voi asentaa myös Ubuntun tai muun Ubuntu-johdannaisen. Jos haluat käyttää ennalta ladattua alternate-versiota (ei työpöytäversiota), käytä HdMedia-valintaa ja aseta alternate-version ISO-tiedosto USB-levyn/kiintolevyn juureen.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="137"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://linuxconsole.org/&quot;&gt;http://linuxconsole.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; LinuxConsole is a desktop distro to play games, easy to install, easy to use and fast to boot .&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The 1.0.2010 is latest 1.0, now available on rolling release (run liveuptate to update modules and kernel).</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="142"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://linuxmint.com/&quot;&gt;http://linuxmint.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Linux Mint is a user-friendly Ubuntu-based distribution which includes additional proprietary codecs and other software by default.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://linuxmint.com/&quot;&gt;http://linuxmint.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Linux Mint on helppokäyttöinen Ubuntu-pohjainen jakelu, jonka oletusasennus sisältää suljettuja koodekkeja ja muita ohjelmistoja.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Live-versio mahdollistaa käynnistyksen live-tilaan, josta asennusohjelma on mahdollista käynnistää.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="147"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.lubuntu.net/&quot;&gt;http://www.lubuntu.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Lubuntu is an official Ubuntu derivative featuring the LXDE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="152"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.mandriva.com/&quot;&gt;http://www.mandriva.com/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Mandriva is a user-friendly distro formerly known as Mandrake Linux.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over the internet (FTP) or via pre-downloaded &lt;a href=&quot;http://www.mandriva.com/en/download&quot;&gt;&quot;Free&quot; iso image files&lt;/a&gt;.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="157"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.mepis.org/&quot;&gt;http://www.mepis.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; MEPIS is a Debian-based distribution. SimplyMEPIS is a user-friendly version based on KDE, while AntiX is a lightweight version for older computers.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; MEPIS supports booting in Live mode, from which the installer can optionally be launched.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="162"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://netbootcd.tuxfamily.org/&quot;&gt;http://netbootcd.tuxfamily.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; NetbootCD is a small boot CD that downloads and boots network-based installers for other distributions.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; NetbootCD boots and runs in live mode.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="172"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.nimblex.net/&quot;&gt;http://www.nimblex.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; NimbleX is a small, versatile Slackware-based distribution. It is built using the linux-live scripts, and features the KDE desktop. It can be booted from CD or flash memory (USB pens or MP3 players), and can easily be customized and extended.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; NimbleX boots in Live mode.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="177"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://pogostick.net/~pnh/ntpasswd/&quot;&gt;http://pogostick.net/~pnh/ntpasswd/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; The Offline NT Password and Registry Editor can reset Windows passwords and edit the registry on Windows 2000-Vista.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; NTPasswd is booted and run in live mode; no installation is required to use it.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="182"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.opensuse.org/&quot;&gt;http://www.opensuse.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; openSUSE is a user-friendly Novell sponsored distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.opensuse.org/&quot;&gt;http://www.opensuse.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; openSUSE on helppokäyttöinen Novellin sponsoroima jakelu.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Oletusversio mahdollistaa asennuksen internetin kautta (FTP:tä käyttäen) tai yhteydettömässä tilassa, jolloin käytetään ennalta ladattuja ISO-asennustiedostoja.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="187"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://ophcrack.sourceforge.net/&quot;&gt;http://ophcrack.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Ophcrack can crack Windows passwords.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Ophcrack is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://ophcrack.sourceforge.net/&quot;&gt;http://ophcrack.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Ophcrack voi murtaa Windows-salasanoja.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Ophcrack käynnistyy live-tilassa; asennusta ei vaadita Ophcrackin käyttämiseksi.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="192"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://partedmagic.com/&quot;&gt;http://partedmagic.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Parted Magic includes the GParted partition manager and other system utilities which can resize, copy, backup, and manipulate disk partitions.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Parted Magic is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://partedmagic.com/&quot;&gt;http://partedmagic.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Parted Magic sisältää GParted-osiohallinnan ja muita järjestelmätyökaluja, joiden avulla on mahdollista muun muassa muuttaa osioiden kokoa, varmuuskopioida sekä tehdä muita toimenpiteitä osioille.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Parted Magic käynnistyy live-tilaan, käyttäminen ei vaadi asennusta.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="202"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.puppylinux.com/&quot;&gt;http://www.puppylinux.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Puppy Linux is a lightweight distribution designed for older computers.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.puppylinux.com/&quot;&gt;http://www.puppylinux.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Puppy Linux on vanhoille tietokoneilla suunnattu jakelu.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Live-versio lataa järjestelmän kokonaisuudessaan keskusmuistiin, joten asennus kiintolevylle ei ole välttämätöntä.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="207"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.sabayonlinux.org/&quot;&gt;http://www.sabayonlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Sabayon Linux is a Gentoo-based Live DVD distribution which features the Entropy binary package manager in addition to the source-based Portage.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The LiteMCE edition is 2 GB, while the full edition will need an 8 GB USB drive</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="214"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://salixos.org&quot;&gt;http://salixos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Salix is a GNU/Linux distribution based on Slackware (fully compatible) that is simple, fast and easy to use.&lt;br/&gt;Like a bonsai, Salix is small, light &amp; the product of infinite care.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.&lt;br/&gt;Default root password is &lt;b&gt;live&lt;/b&gt;.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="224"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.slax.org/&quot;&gt;http://www.slax.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Slax is a Slackware-based distribution featuring the KDE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.slax.org/&quot;&gt;http://www.slax.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Slax on Slackwareen pohjautuva KDE-työpöydällä varustettu jakelu.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Live-versio mahdollistaa käynnistyksen live-tilaan, josta asennusohjelma on mahdollista käynnistää.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="229"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.slitaz.org/en/&quot;&gt;http://www.slitaz.org/en&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; SliTaz is a lightweight, desktop-oriented micro distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="234"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://btmgr.sourceforge.net/about.html&quot;&gt;http://btmgr.sourceforge.net/about.html&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Smart Boot Manager is a bootloader which can overcome some boot-related BIOS limitations and bugs.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; SBM simply boots and runs; no installation is required to use it.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="14"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.supergrubdisk.org&quot;&gt;http://www.supergrubdisk.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Super Grub Disk is a bootloader which can perform a variety of MBR and bootloader recovery tasks.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; SGD simply boots and runs; no installation is required to use it.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="244"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://hacktolive.org/wiki/Super_OS&quot;&gt;http://hacktolive.org/wiki/Super_OS&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Super OS is an unofficial derivative of Ubuntu which includes additional software by default. Requires a 2GB USB drive to install.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="254"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu.com/&quot;&gt;http://www.ubuntu.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Ubuntu is a user-friendly Debian-based distribution. It is currently the most popular Linux desktop distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu.com/&quot;&gt;http://www.ubuntu.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Ubuntu on helppokäyttöinen Debianiin pohjautuva jakelu. Ubuntu lienee suosituin Linux-jakelu työpöytäkäytössä.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Live-versio on mahdollista käynnistää live-tilaan, josta on mahdollista suorittaa varsinainen asennus. NetInstall-versio mahdollistaa asennuksen verkon (FTP) kautta; sillä voi asentaa myös Kubuntun tai muun Ubuntu-johdannaisen. Jos haluat käyttää ennalta ladattua alternate-versiota (ei työpöytäversiota), käytä HdMedia-valintaa ja aseta alternate-version ISO-tiedosto USB-levyn/kiintolevyn juureen.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="259"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.xpud.org/&quot;&gt;http://www.xpud.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; xPUD is a lightweight distribution featuring a simple kiosk-like interface with a web browser and media player.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="264"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.xubuntu.org/&quot;&gt;http://www.xubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Xubuntu is an official Ubuntu derivative featuring the XFCE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Verkkosivusto:&lt;/b&gt; &lt;a href=&quot;http://www.xubuntu.org/&quot;&gt;http://www.xubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Kuvaus:&lt;/b&gt; Xubuntu on virallinen Ubuntu-johdannainen, jonka työpöytäympäristönä on XFCE.&lt;br/&gt;&lt;b&gt;Asennustiedot:&lt;/b&gt; Live-versio on mahdollista käynnistää live-tilaan, josta on mahdollista suorittaa varsinainen asennus. NetInstall-versio mahdollistaa asennuksen verkon (FTP) kautta; sillä voi asentaa myös Kubuntun tai muun Ubuntu-johdannaisen. Jos haluat käyttää ennalta ladattua alternate-versiota (ei työpöytäversiota), käytä HdMedia-valintaa ja aseta alternate-version ISO-tiedosto USB-levyn/kiintolevyn juureen.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="269"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.zenwalk.org/&quot;&gt;http://www.zenwalk.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Zenwalk is a Slackware-based distribution featuring the XFCE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="36"/>
        <source>&lt;img src=&quot;:/eeepclos.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.eeepclinuxos.com/&quot;&gt;http://www.eeepclinuxos.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; EeePCLinuxOS is a user-friendly PCLinuxOS based distribution for the EeePC.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="44"/>
        <source>&lt;img src=&quot;:/eeeubuntu.png&quot; style=&quot;float:left;&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu-eee.com/&quot;&gt;http://www.ubuntu-eee.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Ubuntu Eee is not only Ubuntu optimized for the Asus Eee PC. It&apos;s an operating system, using the Netbook Remix interface, which favors the best software available instead of open source alternatives (ie. Skype instead of Ekiga).&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="56"/>
        <source>&lt;img src=&quot;:/elive.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Elive is a Debian-based distribution featuring the Enlightenment window manager.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="64"/>
        <source>&lt;img src=&quot;:/kiwi_logo_ro.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.kiwilinux.org/&quot;&gt;http://www.kiwilinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Kiwi Linux is an Ubuntu derivative primarily made for Romanian, Hungarian and English speaking users.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="72"/>
        <source>&lt;img src=&quot;:/gnewsense.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.gnewsense.org/&quot;&gt;http://www.gnewsense.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; gNewSense is a high-quality GNU/Linux distribution that extends and improves Ubuntu to create a completely free operating system without any binary blobs or package trees that contain proprietary software.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="80"/>
        <source>&lt;img src=&quot;:/nimblex.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.nimblex.net/&quot;&gt;http://www.nimblex.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; NimbleX is a small, versatile Slackware-based distribution. It is built using the linux-live scripts, and features the KDE desktop. It can be booted from CD or flash memory (USB pens or MP3 players), and can easily be customized and extended.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; NimbleX boots in Live mode.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="88"/>
        <source>&lt;img src=&quot;:/slitaz.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.slitaz.org/en/&quot;&gt;http://www.slitaz.org/en&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; SliTaz is a lightweight, desktop-oriented micro distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional. This installer is based on &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootin&lt;/a&gt;.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="96"/>
        <source>&lt;img src=&quot;:/xpud.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.xpud.org/&quot;&gt;http://www.xpud.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; xPUD is a lightweight distribution featuring a simple kiosk-like interface with a web browser and media player.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory.</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>unetbootinui</name>
    <message>
        <location filename="unetbootin.ui" line="20"/>
        <source>Unetbootin</source>
        <translation>Unetbootin</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="65"/>
        <source>Select from a list of supported distributions</source>
        <translation>Valitse tuettujen jakeluiden luettelosta</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="47"/>
        <source>&amp;Distribution</source>
        <translation>&amp;Jakelu</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="131"/>
        <source>Specify a disk image file to load</source>
        <translation>Valitse levykuva</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="134"/>
        <source>Disk&amp;image</source>
        <translation>Levy&amp;kuva</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="147"/>
        <source>Manually specify a kernel and initrd to load</source>
        <translation>Valitse itse ladattava kernel ja initrd</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="150"/>
        <source>&amp;Custom</source>
        <translation>&amp;Mukautettu</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="430"/>
        <source>Space to reserve for user files which are preserved across reboots. Works only for LiveUSBs for Ubuntu and derivatives. If value exceeds drive capacity, the maximum space available will be used.</source>
        <translation>Käyttäjän tiedostoja varten varattava tila uudelleenkäynnistysten välillä. Toimii vain Live-USB-asennuksissa Ubuntulla ja sen jälkeläisillä. Jos arvo ylittää aseman kapasiteetin, käytetään kaikki mahdollinen tila.</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="417"/>
        <source>Space used to preserve files across reboots (Ubuntu only):</source>
        <translation>Uudelleenkäynnistysten välillä säilytettävä tila (vain Ubuntu):</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="440"/>
        <source>MB</source>
        <translation>Mt</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="503"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="506"/>
        <source>Return</source>
        <translation>Takaisin</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="513"/>
        <source>Cancel</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="516"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="561"/>
        <source>Reboot Now</source>
        <translation>Käynnistä uudelleen nyt</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="568"/>
        <source>Exit</source>
        <translation>Lopeta</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="660"/>
        <source>1. Downloading Files</source>
        <translation>1. Ladataan tiedostoja</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="667"/>
        <source>2. Extracting and Copying Files</source>
        <translation>2. Puretaan ja kopioidaan tiedostoja</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="674"/>
        <source>3. Installing Bootloader</source>
        <translation>3. Asennetaan käynnistyslataajaa</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="681"/>
        <source>4. Installation Complete, Reboot</source>
        <translation>4. Asennus valmis, uudelleenkäynnistä</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="496"/>
        <source>Select the target drive to install to</source>
        <translation>Valitse kohdeasema, johon asennus suoritetaan</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="480"/>
        <source>Dri&amp;ve:</source>
        <translation>A&amp;sema:</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="470"/>
        <source>Select the installation target type</source>
        <translation>Valitse asennuksen kohdetyyppi</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="454"/>
        <source>&amp;Type:</source>
        <translation>&amp;Tyyppi:</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="81"/>
        <source>Select the distribution version</source>
        <translation>Valitse jakeluversio</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="347"/>
        <source>Select disk image file</source>
        <translation>Valitse levykuvatiedosto</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="400"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="188"/>
        <source>Select the disk image type</source>
        <translation>Valitse levykuvan tyyppi</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="243"/>
        <source>Specify a floppy/hard disk image, or CD image (ISO) file to load</source>
        <translation>Valitse ladattava disketti- tai kiintolevykuva, tai CD-levykuva (ISO-tiedosto)</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="258"/>
        <source>Specify a kernel file to load</source>
        <translation>Valitse ladattava kernel</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="283"/>
        <source>Select kernel file</source>
        <translation>Valitse kernel-tiedosto</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="312"/>
        <source>Specify an initrd file to load</source>
        <translation>Valitse ladattava initrd-tiedosto</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="372"/>
        <source>Select initrd file</source>
        <translation>Valitse initrd-tiedosto</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="397"/>
        <source>Select syslinux.cfg or isolinux.cfg file</source>
        <translation>Valitse syslinux.cfg- tai isolinux.cfg-tiedosto</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="321"/>
        <source>Specify parameters and options to pass to the kernel</source>
        <translation>Valitse kernelille välitettävät parametrit ja valinnat</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="210"/>
        <source>&amp;Kernel:</source>
        <translation>&amp;Kernel:</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="296"/>
        <source>Init&amp;rd:</source>
        <translation>Init&amp;rd:</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="229"/>
        <source>&amp;Options:</source>
        <translation>&amp;Valinnat:</translation>
    </message>
</context>
<context>
    <name>uninstaller</name>
    <message>
        <location filename="main.cpp" line="156"/>
        <source>Uninstallation Complete</source>
        <translation>Asennuksen poisto on valmis</translation>
    </message>
    <message>
        <location filename="main.cpp" line="157"/>
        <source>%1 has been uninstalled.</source>
        <translation>%1 on poistettu.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="322"/>
        <source>Must run as root</source>
        <translation>Vaatii suorituksen pääkäyttäjänä</translation>
    </message>
    <message>
        <location filename="main.cpp" line="324"/>
        <source>%2 must be run as root. Close it, and re-run using either:&lt;br/&gt;&lt;b&gt;sudo %1&lt;/b&gt;&lt;br/&gt;or:&lt;br/&gt;&lt;b&gt;su - -c &apos;%1&apos;&lt;/b&gt;</source>
        <translation>%2 on suoritettava pääkäyttäjän oikeuksin. Sulje sovellus ja käynnistä se uudelleen seuraavasti::&lt;br/&gt;&lt;b&gt;sudo %1&lt;/b&gt;&lt;br/&gt;tai:&lt;br/&gt;&lt;b&gt;su - -c &apos;%1&apos;&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="main.cpp" line="361"/>
        <source>%1 Uninstaller</source>
        <translation></translation>
    </message>
    <message>
        <location filename="main.cpp" line="362"/>
        <source>%1 is currently installed. Remove the existing version?</source>
        <translation>%1 on parhaillaan asennettu. Poistetaanko nykyinen versio?</translation>
    </message>
</context>
</TS>
